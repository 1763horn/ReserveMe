## Команды Git
```
git status
git add . // or git add namefile.js
git commit -m "write message here"
git push remoteName branchName
git pull remoteName branchName

git branch // - get branches and current branch
git remote -v //- get remote list
git remote add remoteName https://...

git checkout branchName
git branch branchName // make branch
git checkout -b branchName // make branch and checkout
```
